# def countdown_loop(n):
#    for i in range(n):
#        print (-i+n)

# def countdown_r(n):
#   if n > 0:
#       print(n)
#        countdown_r(n-1)

# countdown_loop(10)
# countdown_r(10)

"""
def split_in_half(n):
    count = 0
    new_list = []
    for i in n:
        if len(n) == n/2:

"""

# s = [1,2,3,4,5,6,7,8,9]
# num = number in fib sequence

"""
def recur_fibo(n)":
    print(n)
    if n <= 1:
        return n
    else:
        return (recur_fibo(n - 1) + recur_fibo(n - 2))


recur_fibo(10)
"""


def binary_tree(n):
    if n == 0:
        return n
    else:
        if binary_tree(n) > binary_tree(n - 1):

